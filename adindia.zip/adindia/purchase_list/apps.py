from django.apps import AppConfig


class PurchaseListConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'purchase_list'

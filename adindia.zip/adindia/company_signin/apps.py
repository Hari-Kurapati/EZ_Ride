from django.apps import AppConfig


class CompanySigninConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'company_signin'

from django.shortcuts import render
from django.contrib import messages
from company_signup.models import Advertisers
from user_login.models import User_Purchase_List
# Create your views here.
def company_signin(request):
    if request.method == "POST":
        email = request.POST.get('email')
        passw = request.POST.get('password')

        query = f"SELECT * FROM company_signup_advertisers WHERE company_email = '{email}' AND company_password = '{passw}'"

        t = list(Advertisers.objects.raw(query))

        rating_list = []
        i = 0
        for item in t:
            rating_query = f"select id,avg(rating) as avg from user_login_user_purchase_list " \
                           f"where company_email = '{item.company_email}' and ad_name='{item.ad_name}' and ad_price='{item.ad_price}' and rating IS NOT NULL"
            avg_rating = tuple(User_Purchase_List.objects.raw(rating_query))
            if not (avg_rating[0].avg):
                avg_rating = -1
            else:
                avg_rating = avg_rating[0].avg
            rating_list.append(avg_rating)
            t[i].rating = "{:.1f}".format(avg_rating)
            i = i + 1

        if t==[]:
            messages.success(request, "Incorrect email address or password")
        else:
            query1 = f"SELECT id,company_name FROM company_signup_advertisers WHERE company_email = '{email}' AND company_password = '{passw}'"
            name = tuple(Advertisers.objects.raw(query1))[0]
            #return render(request, 'company_product.html', {'companies': Advertisers.objects.get(company_email=email)})
            return render(request, 'company_product.html', {'companies': t,
                                                            'company_name': name})

    return render(request, 'company_signin.html')
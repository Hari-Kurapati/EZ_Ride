from django.apps import AppConfig


class CompanySignupConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'company_signup'
